if (window != window.top) top.location.href = location.href;
ghcc='a';ghd='a';ghe='a';ghf=0;ghs='a0';
a0=' width='; a1=' height=';  a2=' align='; a3=' valign='; a4=' bgcolor='; a5=' border='; a6=' bordercolor='; a7=' alt=';  a8=' target=';  a9=' name='; a10=' type='; a11=' action='; a12=' method='; a13=' value='; a14=' size='; a15=' quality=';
a16=' onmouseover=this.className=';a17=' onmouseout=this.className=';a18='display:inline;';
c0='"#000000"'; c1='"#ffffff"'; c2='"#003399"'; c3='"#0099cc"'; c4='"#cc3300"';
s0='<div'; s1=' class='; s2='</div>'; saw='"saw"'; s3=s1+saw; s4=' style=';
s5='"width:'; s6='"text-align:'; s7=' id='; s8='<span';s9='</span>';s21='left';s22='center';s23='right';s30='<area shape=rect coords=';s31='<map name="';s32='</map>';
sh2='"sh2"'; sh4='"sh4"'; sh6='"sh6"'; sm='"sm"'; sn='"sn"'; sn0='"sn0"'; sf='"sf"'; st12='"st12"';
st13='"st13"'; st14='"st14"'; st14s='"st14s"'; st15='"st15"';
si1='"si1"'; si2='"si2"'; si3='"si3"'; si4='"si4"'; si5='"si5"'; si6='"si6"'; si7='"si7"'; si8='"si8"'; sb1='"sb1"'; sb2='"sb2"'; sb3='"sb3"';
sxht='"sxht"';sxh='"sxh"';sxh1='"sxh1"';sxh2='"sxh2"';sxh3='"sxh3"';sxh4='"sxh4"';sxt='"sxt"';sxc0='"sxc0"';sxc2='"sxc2"';sxc3='"sxc3"';sxc3b='"sxc3b"';sxb1='"sxb1"';sxb2='"sxb2"';sxb3='"sxb3"';sxb3b='"sxb3b"';sxa1='"sxa1"';sxa2='"sxa2"';sxa3='"sxa3"';sxa3b='"sxa3b"';
sxs='"sxs"';sxd='"sxd"';sx0='"sx0"';sx1='"sx1"';sxi1='"sxi1"';sxi2='"sxi2"';sxi3='"sxi3"';sxi4='"sxi4"';sxi5='"sxi5"';sxi6='"sxi6"';sxi7='"sxi7"';
v0='"0"'; v1='"1"'; v2='"2"'; v3='"3"'; v4='"4"'; v5='"5"'; v6='"6"'; v7='"7"'; v8='"8"'; v9='"9"'; v10='"10"'; v12='"12"'; v18='"18"'; v20='"20"'; v24='"24"'; 
v30='"30"'; v40='"40"'; v46='"46"'; v60='"60"'; v80='"80"'; v96='"96"';
v100='"100"'; v105='"105"'; v110='"110"'; v120='"120"'; v128='"128"'; v130='"130"'; 
v140='"140"'; v150='"150"'; v158='"158"'; v160='"160"'; v170='"170"'; v180='"180"'; v190='"190"'; 
v200='"200"'; v210='"210"'; v220='"220"'; v230='"230"'; v240='"240"'; v248='"248"'; v310='"310"'; 
v320='"320"'; v330='"330"'; v360='"360"'; v460='"460"'; v480='"480"'; v600='"600"';
v670='"670"'; v690='"690"'; v700='"700"'; v720='"720"'; 
ddma=new Array('a39z','c82a','e9s0','f59m','gs9z','i9zb','my2u','p9vq','qpqw','rvx8','sp5x','tp44');
vj='.jpg'; vg='.gif'; vh='.htm'; vl='.html'; vs='.js'; vf='.swf';
vn=0; vni=1; vn2=2; vnx=10;vn15=15; vn30=30;  vn59=59; vn60=60; vn72=72; vnc=100; vn200=200; vnm=1000; 
x=' '; xn=' '; x0='<'; x1='>'; x3='</'; x4='<br>'; x5=x4+x4; x6='&#160;'; 
x7='&#62;'; x8=x6+x6; x9='&#64;';  x10='&#61;'; x11=' &#61; '; 
x12='&#38;'; x13=','; x14='.'; x15=''; x16=':'; x17=';'; x20='0'; 
y='"'; yn='"'; y0='""'; y1='"left"'; y2='"center"'; y3='"right"'; y4='"top"'; y5='"middle"'; y6='"bottom"'; y7='"_blank"'; y8='"_self"'; y10='"get"'; y11='"post"'; y12='"on"'; y13='"off"'; y14='"high"'; y15='embed'; y16='html'; y17='head'; y18='body'; y19='object';
z='/'; z4='"mailto:'; z5='Mail'; z6='Copyright &#169; ';
d0='<img'; d1=' src='; 
jv0='<applet'; jv1=' code='; jv2=' codebase='; jv3=' archive='; jv4='</applet>'; jv5='<param'; jv6='<object'; jv7='</object>';
h0='<a href='; h1='</a>'; h2=x6+h1+x4; h3='javascript:'; h40=' onfocus='; h4=h40+yn; h41='this.blur()'; h42=h40+h41; h50=' onchange='; h5=h50+yn; h60=' onclick='; h6=h60+yn; h7='script'; h8='<a'+s3+' href='; 
k0s='"https://'; k10='www.'; k1=k0+k10; k1s=k0s+k10; k3=k1+z1+zn; k4='index.htm'; k5=h0+k2+yn; k7=h0+k2; k8='i/st'+vg+yn; k8b='i/t1'+vg; k9='http://'; k11=k9+z0+zn; k12=k2+'jv'+zn; cm='.com/'; k13=k11+k8b;
k14=k9+k10+z8+zn; k15=k2+'directorio/'; k16=k2g+k8b+yn; k17='directorio/'; k18=k9+k10; kb=k2+'i/b/'; 
m1=yn+a8+y7;m0=m1+x1+x6;m2=m1+s7;m3=s1+'"txt"';
r0='<form'; r1='<input'; r2=' maxlength='; r3='"text"'; r4='"hidden"'; r5='"radio"'; r6='"submit"'; r7='"checkbox"'; r8=' checked'; r9='</form>'; r10='<option'; r11='<select'; r12='</select>'; r13=' selected'; r14='"button"'; 
t0='<table'; t1='<tr'; t2='<td'; t3=' cellspacing='; t4=' cellpadding='; t5=' colspan='; t6='<tr>'; t7='</td>'; t8='</tr>'; t9='</table>'; t10=t7+t8; t11=t10+t9; t12=t11+x4; t13=s2+t11; t14=s2+t12;  t15=t2+x1;
pchr=document.referrer; pchre=escape(pchr); pchw=screen.width; pchh=screen.height;
b1a=a2+y2+t3+v0+t4+v2+a5+v0+x1+t6+t2+a0+v20+a2+y2+a4+c2+x1+d0+s1+si4+d1+k2g+k8+x1+t7+t2+a0;
b1a2=a2+y1+a4+c4+x1+s0+s1+st12+x1;
b1a23=a2+y1+a4+c2+x1+s0+s1+st12+x1;
b1b=s2+t10+t6+t2+t5+v2+a2+y1+a4; b1c=x1+s0+s1+st13+x1;
b1h1=t0+a0+v210+b1a+v190+b1a2;b1h1b=t0+a0+v210+b1a+v190+b1a23;bh2=b1b+c3+b1c;
b1h2=t0+a0+v330+b1a+v310+b1a23+x6;b1h3=t0+a0+v690+b1a+v670+b1a23+x6;
b1d=t1+s1+st14+a16+st14s+a17+st14+x1;
bs1=yn+x1+x3+h7+x1;
ddda=new Array('j1sv8','a2tns','a7ikh','b3kyn','b9xsd','c10op','c282s','d08xq','d7t56','d9h3x','e9h3y','f78iy','f88py','f9uuy','g89fg','g91h7','h9vbh','j1sv8','klxcv','m29op','n3ert','n7w5s','n9imj','pqps5','pwip3','qxvy4','rav4t','rqw49','rw9uh','s97ht','tuu4t','tzp8x');
it1=d0+d1+k3+'l/gen/t1'+vg+yn+a0+v1+a1+v1+a5+v0+x1;
ibt=d0+d1+k2g+'i/bt'+vg+yn+s1+'"bt"'+x1;
ib1=m1+h42+x1+d0+s1+sb1+d1;ib2=x1+h1+x5;ib3=x1+h1;

function isundef(param){return (typeof(param)=='undefined'||param==null)}
function isdef(param){return !isundef(param)}
function isval(param){return !isundef(param) && param!=''}
function isval2(param,value){return !isundef(param) && param==value}
function ghc(){document.getElementById("gh1").src=k14+n1+ghcc+vj;}
ghe0='ghd=this.id;srdtf();ght();';
ghef='ghd=this.id;srdtf();this.href=ghtf(this.href,this.innerHTML);';
ghe=ghef+yn;ghe2=h6+ghe+x1+x6;ghe3=m3+h6+'setHome(event,k11);'+ghe0+yn+x1+x6+z12+h2;ghe3f=m3+h6+'setHome(event,k11);'+ghe0+yn+x1+x6+z13+h2;
ghe4=h6+ghe0+m1+h42+x1+d0+s1;
function ght(){if(rn1<ghf){document.getElementById("gh1").src=k9+ghs+z9+zn+'c'+n0+'_'+ge0d()+'_ti_'+srdtn+'_p_'+n1+'_lid_'+ghd+vj;}}
function ghtf(url,text){
var lnk='';var seg='';
if(typeof(fv)!='undefined'&&fv!=null){
var elnk=ghd.indexOf("e");if(elnk!=-1){lnk=ghd.substring(elnk);seg=ghd.substring(0,elnk)}
var plnk=ghd.indexOf("p");if(plnk!=-1){lnk=ghd.substring(plnk);seg=ghd.substring(0,plnk)}
if(lnk!=''&&seg!='s0'){
var segorig=seg;var fnd=false;
for(i=0;i<fv.length&&!fnd;i++){fnd=fv[i].slice(0, lnk.length)==lnk}
if(fnd){segorig=fv[i-1].substring(fv[i-1].lastIndexOf('|')+1);if(seg!=segorig){var elem=document.getElementById(segorig+lnk);if(elem!=null){url=elem.href;text=elem.innerHTML;}} fv.splice(i-1,1);}else{fv.splice(0,1);}
text=text.replace(/^(&nbsp;)+/g,'');
fv[fv.length]=lnk+'~|'+url+'~|'+text.substring(0,text.length-6)+'~|'+segorig;
var fvstr='';for(i=0;i<fv.length&&i<7;i++){if(i!=0){fvstr+='~^'}fvstr+=fv[i]}
setck('favs',fvstr,9999);}}
if(seg.substring(0,1)=='s'){ght()};return url;}
function ghtfn(pgid,url,text){ghd=pgid;ghtf(url,text);}

function ghtp(obj,ckkey){ghd=obj.id;srdtf();var ghtpv=ghtpf(obj,['firstChild','title'],ckkey);obj.href=ghtpv[0];if(isval(ghtpv[1])){obj.target=ghtpv[1];}}
function gprp(obj,props){var el=obj;for(var ip=0;ip<props.length;ip++){el=el[props[ip]];}return el;}
function ghtpf(obj,props,ckkey){
var url=obj.href;var targ=obj.target;var text=gprp(obj,props);if(isundef(text)){text=obj.innerHTML;};
if((typeof(fv)!='undefined'&&fv!=null)){
var lnk='';var seg='';
var elnk=ghd.indexOf("e");if(elnk!=-1){lnk=ghd.substring(elnk);seg=ghd.substring(0,elnk)}
var plnk=ghd.indexOf("p");if(plnk!=-1){lnk=ghd.substring(plnk);seg=ghd.substring(0,plnk)}
if(lnk!=''&&seg!='s0'){
var segorig=seg;var fnd=false;
for(i=0;i<fv.length&&!fnd;i++){fnd=fv[i].slice(0, lnk.length)==lnk}
if(fnd){var fvi=fv[i-1].split('~|');segorig=fvi[3];if(seg!=segorig){var elem=document.getElementById(segorig+lnk);if(elem!=null){url=elem.href;text=gprp(elem,props);targ=elem.target}}fv.splice(i-1,1);}else{fv.splice(0,1);}
text=(text.replace(/^(&nbsp;)+/g,'').replace(/(&nbsp;)+$/g,''));
fv[fv.length]=lnk+'~|'+url+'~|'+text+'~|'+segorig+(isval(targ)?'~|'+targ:'');
var fvstr='';for(i=0;i<fv.length&&i<7;i++){if(i!=0){fvstr+='~^'}fvstr+=fv[i]}
setck(ckkey,fvstr,9999);}}
if(seg.substring(0,1)=='s'){ght()};return [url,targ];}

function ghz(ghcc,ghst,ty){srdtf();document.getElementById("gh1").src=k9+ghs+z9+zn+'z'+n0+'_'+ge0d()+'_ti_'+srdtn+'_p_'+n1+'_id_'+ghcc+'_ty_'+ty+'_z_'+((typeof(encodeURIComponent)=='undefined')?ghst:encodeURIComponent(ghst))+vj;}
function i(url,iwd,ihg,ibo,ibc,iat){document.writeln(d0+d1+url+a0+iwd+a1+ihg+a5+ibo+a6+ibc+a7+iat+x1)};
function im(url,iwd,ihg,ibo,ibc,iat){document.writeln(d0+d1+url+a0+iwd+a1+ihg+a5+ibo+a6+ibc+a7+iat+x1)};
function is(icl,url,iat){document.writeln(d0+s1+icl+d1+url+a7+iat+x1)};
function it(hk,hc,hl,hcl,hloc,hhgt,hz){document.writeln(h0+hk+hc+yn+s7+hl+ghe4+hcl+d1+hloc+yn+a1+hhgt+hz)};
function itc(hk,hc,hl,hcl,hloc,hz){document.writeln(h0+hk+hc+yn+s7+hl+ghe4+hcl+d1+hloc+yn+hz)};
function itx(h,hs,hz){if(h!=null){if(h[6]==''){if(h[0]!='' && h[3]!=''){document.writeln(h0+h[0]+yn+s7+hs+h[1]+ghe4+h[2]+d1+h[3]+yn+hz)}}else{eval(h[6])};if(h[7]){e0i=ge0i()+hs+h[1];}}};
function h(hk,hc,ht){document.writeln(h0+hk+hc+m0+ht+h2)};
function ha(hk,hc,ht,ha){document.writeln(h0+hk+hc+m0+ht+x6+h1+ha+x4)};
function hw(hk,hc,ht){document.writeln(h8+hk+hc+m0+ht+h2)};
function l(hc,ht){document.writeln(h0+k1+hc+ch+m0+ht+h2)};
function m(hc,ht){document.writeln(h0+k1+hc+cm+m0+ht+h2)};
function hn(hk,hc,ht){document.writeln(h0+hk+hc+m0+ht+x6+h1)};

function hb(hk,hc,hl,ht){document.writeln(h0+hk+hc+m2+hl+m3+ghe2+ht+h2)};
function hbc(tls,hk,hc,hl,ht){document.writeln(h0+hk+hc+yn+s1+tls+a8+y7+s7+hl+ghe2+ht+h2)};
function hbc2(tls,hk,hc,hl,ht){document.writeln(h0+hk+hc+yn+s1+tls+a8+y7+s7+hl+ghe2+ht+h1)};
function hh(hc,hl,ht){document.writeln(h0+k1+hc+ch+m2+hl+ghe2+ht+h2)};
function hm(hc,hl,ht){document.writeln(h0+k1+hc+cm+m2+hl+ghe2+ht+h2)};
function hbn(hk,hc,hl,ht){document.writeln(h0+hk+hc+m2+hl+m3+ghe2+ht+x6+h1)};
function hbt(hk,hc,hl,ht){document.writeln(ibt+h0+hk+hc+m2+hl+m3+h6+ghe+x1+ht+h2)};
function hb2(hk,hc,hl,ht){document.writeln(h0+hk+hc+m2+hl+m3+h6+ghe+x1+ht+h1)};
function hbt2(hk,hc,hl,ht){document.writeln(ibt+h0+hk+hc+m2+hl+m3+h6+ghe+x1+ht+h1)};
function hbx(h,hs,hf){if(h!=null){if(h[0]!='' && h[4]!=''){document.writeln(h0+h[0]+m2+hs+h[1]+m3+ghe2+h[4]+((h[5]=='')?h[5]:x6+x4+x8+x8+h[5])+x6+h1+((hf==1)?x4:((hf==2)?x5:'')))};if(h[7]){e0i=ge0i()+hs+h[1];}}};
function t(twd,tha,tva,tcs,tcp,tbg,tbo,tbc){document.writeln(t0+a0+twd+a2+tha+a3+tva+t3+tcs+t4+tcp+a4+tbg+a5+tbo+a6+tbc+x1)};
function tc(tls,twd,tha,tva,tcs,tcp,tbg,tbo,tbc){document.writeln(t0+s1+tls+a0+twd+a2+tha+a3+tva+t3+tcs+t4+tcp+a4+tbg+a5+tbo+a6+tbc+x1)};
function tx(tls,tha,tva,tcs,tcp,tbg,tbo,tbc){document.writeln(t0+s1+tls+a2+tha+a3+tva+t3+tcs+t4+tcp+a4+tbg+a5+tbo+a6+tbc+x1)};
function td(twd,tcl,tha,tva,tbg){document.writeln(t2+a0+twd+t5+tcl+a2+tha+a3+tva+a4+tbg+x1)};
function tdx(tls,tcl,tha,tva,tbg){document.writeln(t2+s1+tls+t5+tcl+a2+tha+a3+tva+a4+tbg+x1)};
function tdc(tls,twd,tcl,tha,tva,tbg){document.writeln(t2+s1+tls+a0+twd+t5+tcl+a2+tha+a3+tva+a4+tbg+x1)};
function dn(tcl,tha,tva,tbg){document.writeln(t2+t5+tcl+a2+tha+a3+tva+a4+tbg+x1)};
function b0(hd){document.writeln(b1h1+hd+bh2)};
function b1(hd){document.writeln(b1h1b+hd+bh2)};
function b2(hd){document.writeln(b1h2+hd+bh2)};
function b3(hd){document.writeln(b1h3+hd+bh2)};
function bx(tcl1,tcl2,tbg){document.writeln(t0+s1+tcl1+a2+y2+t3+v0+t4+v2+a5+v0+x1+t6+t2+s1+sxs+a2+y2+a4+c2+x1+d0+s1+si4+d1+k2g+k8+x1+t7+t2+s1+tcl2+a2+y1+a4+tbg+x1+s0+s1+st12+x1)};

function cimg() {document.location.reload();}
function fr(rn,rg,ra,rm){document.writeln(r0+a9+rn+a8+rg+a11+ra+a12+rm+x1)};
function jsc(jss){document.writeln(x0+h7+d1+k2+jss+vs+bs1)};
function jsc0(jss){document.writeln(x0+h7+d1+k2g+jss+vs+bs1)};
function jscx(jsx){document.writeln(x0+h7+d1+k2+jsx+bs1)};
function jsch(jsh,jsx){document.writeln(x0+h7+d1+k0+jsh+zn+jsx+bs1)};
function jva(jvc,jvcb,jvf,jvw,jvh,jvx){document.writeln(jv0+jv1+jvc+jv2+jvcb+jv3+jvf+a0+jvw+a1+jvh+jvx+x1)};
function jvp(jvn,jvv,jvx){document.writeln(jv5+a9+jvn+a13+jvv+jvx+x1)};
function ri(rn,rt,rx){document.writeln(r1+a9+rn+a10+rt+rx+x1)};
function ro(roc,rov){document.writeln(r10+a13+roc+x1+rov)};
function sfu(scl){document.writeln(s0+s1+scl+x1)};
function sid(v1,v2){document.writeln(s0+s7+yn+v1+yn+x1+v2+s2)};
function v(v1){document.writeln(v1)};
function vop(v1){document.writeln(x0+v1+xn)};
function vst(v1){document.writeln(x0+v1+x1)};
function ven(v1){document.writeln(x3+v1+x1)};
function srwog(srwou,wname,srwow,srwoh){
var srwogv=window.open(srwou,wname,'width='+srwow+',height='+srwoh+',toolbar=no,location=no,directories=no,resizable=no,status=no,scrollbars=no,menubar=no,left=150,top=150');
srwogv.focus()}
function rnr(rnx){if(rnx<1){return 0;} return Math.floor(Math.random()*rnx)+1}
rn1=rnr(100);rn2=rnr(2);rn3=rnr(3);rn4=rnr(4);rn5=rnr(5);rn6=rnr(6);rn7=rnr(7);rn8=rnr(8);rn9=rnr(9);rn10=rnr(10);

month2=new Array("1","2","3","4","5","6","7","8","9","10","11","12");
function srdty2k(number) { return (number < 1000) ? number + 1900 : number; }
function srdget(srdpar){
srdlv=new Date();
if(typeof(srdpar)!='undefined' && srdpar!=null && srdpar!=''){srdlvd=new Date(srdpar.substring(0,4),(srdpar.substring(4,6))-1,srdpar.substring(6),srdlv.getHours(),srdlv.getMinutes(),srdlv.getSeconds());
srdlv.setTime(srdlvd.getTime()+(Math.random()*1000))}
return srdlv;}
function srdsd(srdpar) { 
now=srdget(srdpar);
srdth=now.getHours(); srdtu=now.getMinutes(); srdts=now.getSeconds(); srdti=now.getTime();
srdtd=now.getDay(); srdtt=now.getDate(); srdtm=now.getMonth();
srdty=srdty2k(now.getYear());
   dt=day[srdtd]+xn+srdtt+' '+month_pre+month[srdtm]; 
srdt1=day[srdtd]+xn+srdtt+' '+month_pre+month[srdtm];
srdtmy=month2[srdtm]+'y'+srdty;
srdtdm3=srdtt+xn+month3[srdtm];
srdtdmy=srdtt+'m'+month2[srdtm]+'y'+srdty;
srdymt=''+srdty+((srdtm<9)?'0'+(srdtm+1):srdtm+1)+((srdtt<10)?'0'+srdtt:srdtt);
if(va1a==srdty){va1=va1a;}else{va1=va1a+'-'+srdty;}
g1d=srdtt/2;g1r=1;if (g1d==Math.floor(g1d)){g1r=2}  
srcchbns=srcchb('ns'); srcchbss=srcchb('ss') ;
srcchhns=srcchh('ns'); srcchhss=srcchh('ss') ;
}
function srcchb(srcchbv){var srcchbr=''; if (srcchbv=='ns') {srcchs='?'}
else {srcchs=x17}
srcchbr+=srcchs+srdtdmy+'h'+srdth+'m'+srdtu+'s'+srdts;
return srcchbr}
function srcchh(srcchhv){var srcchhr=''; if (srcchhv=='ns') {srcchhs='?'}
else {srcchhs=x17}
srcchhr+=srcchhs+srdtdmy;
return srcchhr}
var srbrd=navigator.appName; 
{if (srbrd=="Microsoft Internet Explorer") {srbrdv='ie'} else srbrdv='gn'}
pchr0=x15;
function srdtf(){now2=srdget(srdymt);srdti2=now2.getTime();srdtn=Math.round((srdti2-srdti)/1000)}

function setHome(event, homeUrl){
if (navigator.appName=='Microsoft Internet Explorer'){document.body.style.behavior="url(#default#homepage)";document.body.setHomePage(homeUrl);}
else if (document.getElementById){alert(z10);}
else {alert(z11);}
if (event.preventDefault){event.preventDefault();}else{event.returnValue=false;}}
function getHost(del){
if(typeof(del)=='undefined'){del='\/';}
var host=location.href;
if(host.substring(0,7) == 'http:\/\/'){host=host.substring(7);}
var pos=host.indexOf(del);
if(pos>-1){host=host.substring(0,pos);}
return host;}
function isProd(host){return(typeof(host)=='undefined'||host==null||host.substring(0,3)!='10.')}
function contains(arr,el){if(arr==null){return false;} for(var i=0;i<arr.length;i++){if (arr[i]==el){return true;}}return false;}
function csp(sp){
if(typeof(e0[sp])=='undefined'||e0[sp]==null){return null;}
var len=e0[sp].length;if(len==0){return null;}
var sfxd=contains(e0f,sp);
var s1=sfxd?0:rnr(len)-1;var tr=0;
while(contains(e0u[sp],s1) && tr<len){s1=(s1+1)%len;tr+=1;}
if(sfxd&&e0mix[s1]>=len){return null;}
if(tr<len){e0u[sp][e0u[sp].length]=s1;}
if(sfxd){s1=e0mix[s1];}
var s2=0;len=e0[sp][s1].length;
if(len>1){
s2=rnr(len)-1;tr=0;
while(contains(e0uc,e0[sp][s1][s2][1]) && tr<len){s2=(s2+1)%len;tr+=1;}
if(tr<len){e0uc[e0uc.length]=e0[sp][s1][s2][1];}}
return e0[sp][s1][s2];}
function ge0d(){return((typeof(e0d)=='undefined'||e0d==null)?'':e0d)}
function ge0i(){return((typeof(e0i)=='undefined'||e0i==null)?'':e0i)}
function getck(lck){if (document.cookie.length > 0){ begin = document.cookie.indexOf(lck+"=");
if (begin != -1){ begin += lck.length+1;end = document.cookie.indexOf(";", begin);
if (end == -1) end = document.cookie.length;return unescape(document.cookie.substring(begin, end));}}
return null;}
function setck(lck, lckv, lexpd){var lexp = new Date ();
lexp.setTime(lexp.getTime() + (lexpd * 24 * 3600 * 1000));
document.cookie = lck + '=' + escape(lckv) + ((lexpd == null)?'':'; expires='+lexp.toGMTString())+'; path=/';}
function setsc(lsc){if(lsc<2||lsc>6){return false;}else{setck('sc',lsc,9999);return true;}}
function loadcss(lsc){
if((typeof(lsc)!='undefined')&&lsc!=null){e0rc=parseInt(lsc);if(e0rc>6){if(e0rc>12){e0rc=5}else if(e0rc>10){e0rc=4}else if(e0rc>8){e0rc=3}else if(e0rc>6){e0rc=2}} setsc(e0rc)}
else if (pchw<761){e0rc=2;}
else if (pchw<1091){e0rc=3;}
else if (pchw<1371){e0rc=4;}
else if (pchw<1941){e0rc=5;}
else {e0rc=6;}
if(typeof(e0rc)=='undefined'||e0rc==null){e0rc=4;}
if(e0rc<2){e0rc=2;}
else if(e0rc>6){e0rc=6;}
if (e0rc==5||e0rc==6){k8=k8='i/st2'+vg+yn;ibt=d0+d1+k2g+'i/bt2'+vg+yn+s1+'"bt"'+x1}
var qsl=getQueryString();
var content=qsl['content'];
var ckcont=getck('cont');
if((pchw<260&&isval2(content,'mobile')&&isundef(ckcont))||isval2(content,'scroll')||((isundef(content)||isval2(content,'mobile'))&&isval2(ckcont,'scroll'))){location.href=k11+'m'}
else if(isval2(content,'touch')||(isundef(content)&&(isval2(ckcont,'touch')))||(isval2(content,'mobile')&&!isval2(ckcont,'html'))){
setck('cont','touch',9999);
var e0rw=1159;
if(e0rc==2){e0rw=620}
else if (e0rc==3){e0rw=690}
else if (e0rc==4){e0rw=863}
else if (e0rc==5){e0rw=1035}
v('<meta name="viewport" content="width='+e0rw+', minimum-scale=0.4" />')
v('<link rel="stylesheet" type="text/css" href='+k2g+'css/csa2t-'+e0rc+'.css"/>')
}else{
setck('cont','html',9999);
v('<link rel="stylesheet" type="text/css" href='+k2g+'css/csa2-'+e0rc+'.css"/>')
}}
function udfp(lid){udv1=document.uds1.udb1.value; if(udv1!=''){window.open(k9+udv1)};ghd=lid;srdtf();ght();}
function udf1(lid){udv1=document.uds1.udb1.value; if(udv1!=''){window.open(k11+udv1)};ghd=lid;srdtf();ght();}
function udf2(){document.uds1.udb1.value='';}
function trefresh(tout) {setTimeout("location.reload(true);",tout);}
function mt2c(){if(srdth<1){tout=7200;}else if(srdth<2){tout=90000;}else {tout=93600-(srdth*3600);}
tout=tout-(srdtu*60)-srdts;
if(tout<3600){tout=86400;}
return tout*1000;}
function getQueryString(){
var url = window.location.toString();
url.match(/\?(.+)$/);
var params = RegExp.$1;
var params = params.split("&");
var queryStringList = {};
for(var iparam=0;iparam<params.length;iparam++){var tmp = params[iparam].split("=");queryStringList[tmp[0]] = unescape(tmp[1]);}
return queryStringList;}

e0h=getHost();
e0rf=1;e0rc=4;loadcss(getck('sc'));
e0a='js/csp/a.js?'+srdget().getTime();
if(isProd(e0h)){jscx(e0a);}else{jsch(getHost(z14)+z14,e0a);}
